package servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import staticPramer.DefaultPram;

public class FileServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String method = request.getParameter("method");
		if ("upload".equals(method)) {
			upload(request,response);
		}else if ("downList".equals(method)) {
			downList(request,response);
		}else if ("down".equals(method)) {
			down(request,response);
		}
	}
	

	private void upload(HttpServletRequest request, HttpServletResponse response){
		try {
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setHeaderEncoding("UTF-8");		// ���ñ��뷽ʽΪUTF-8
			upload.setFileSizeMax(DefaultPram.MIND);	
			upload.setSizeMax(DefaultPram.MAX);		

			// �ж�
			if (upload.isMultipartContent(request)) {
				List<FileItem> list = upload.parseRequest(request);
			 
				for (FileItem item : list){
					 
					if (item.isFormField()){
						String name = item.getFieldName();
						String value = item.getString();
					} 
					else {
						String name = item.getName();
						String id = UUID.randomUUID().toString().substring(0,4);
						name = id + " " + name;						
						String basePath = getServletContext().getRealPath("/upload");
						System.out.println(basePath);
						File file = new File(basePath,name);
						item.write(file);
						item.delete();  // ɾ���������ʱ��������ʱ�ļ�
						response.sendRedirect("../uploadSuccess.jsp");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			System.out.print("�ļ��ϴ��ɹ�");
		}
			
		
	}
  
	private void downList(HttpServletRequest request, HttpServletResponse response) {
		try{
		 
		Map<String,String> fileNames = new HashMap<String,String>(); 
		String bathPath = getServletContext().getRealPath("/upload");
		 
		File file = new File(bathPath);  
		String list[] = file.list(); 
		if (list != null && list.length > 0){
			for (int i=0; i<list.length; i++){  
				String fileName = list[i];
				String shortName = fileName.substring(fileName.lastIndexOf(" ")+1);
				fileNames.put(fileName, shortName);
			}
		}
		request.setAttribute("fileNames", fileNames);
		request.getRequestDispatcher("/listDwon.jsp").forward(request, response);
		}catch (Exception e) {
			System.out.print("�ļ��ϴ�ʧ��");
		}
	}

	private void down(HttpServletRequest request, HttpServletResponse response){
		try{
		String fileName = request.getParameter("fileName");
		fileName = new String(fileName.getBytes("ISO8859-1"),"UTF-8");
		String basePath = getServletContext().getRealPath("/upload");
		InputStream in = new FileInputStream(new File(basePath,fileName));
		fileName = URLEncoder.encode(fileName, "UTF-8");
		response.setHeader("content-disposition", "attachment;fileName=" + fileName);
		OutputStream out = response.getOutputStream();
		byte[] b = new byte[1024];
		int len = -1;
		while ((len = in.read(b)) != -1){
			out.write(b, 0, len);
		}
		}catch (Exception e) {
			
		}finally {
			try{
			if(out!=null){
				out.close();
			}
			if(in!=null){
				in.close();
			}
			}catch(Exception e){
				
			}
		}
	}
	
}
