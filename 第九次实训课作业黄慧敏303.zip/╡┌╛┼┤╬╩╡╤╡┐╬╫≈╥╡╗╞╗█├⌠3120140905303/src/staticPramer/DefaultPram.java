package staticPramer;

public class DefaultPram {
	public static int MIND = 1024*1024;
	public static int MAX = 1024*1024*10;

}
