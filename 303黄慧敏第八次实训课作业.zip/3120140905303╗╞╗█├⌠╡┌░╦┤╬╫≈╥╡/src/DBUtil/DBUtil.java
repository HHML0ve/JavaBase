package DBUtil;

import java.io.Closeable;
import java.sql.*;

public class DBUtil {
	private Connection conn = null;
	private static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private static String dbURL = "jdbc:sqlserver://localhost:1433;DatabaseName = NewsDB ";
	private static String userName = "sa";
	private static String userPwd = "123456";
	public static Connection getConnection() throws Exception {
	
		Class.forName(driverName);
		if(conn == null){
		 conn = DriverManager.getConnection(dbURL, userName, userPwd);
		 return conn;
		 }else{
		return conn;
		}
	}
	
	public static Close(Connection conn)throws Exception{
		if(conn!=null){
			conn.close();
		}
	}
}
