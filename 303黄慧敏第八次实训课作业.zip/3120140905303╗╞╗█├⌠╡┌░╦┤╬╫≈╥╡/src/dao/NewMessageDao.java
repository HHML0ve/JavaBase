package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import DBUtil.DBUtil;
import bean.New;

public class NewMessageDao {
	public ArrayList<New> selectAllNews(){
		ArrayList<New> al =new ArrayList<New>();
		String sql = "SELECT *FROM NEWMESSAGE ORDER BY TIME";
		try {
			Connection conn = DBUtil.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				New news = new New(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				Date date = new Date(rs.getDate(5).getTime()) ,rs.getString(6),rs.getString(7));
				al.add(news,date,);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(conn);
		}
		
		return al;
	}
	public New selectNewById(New new1){
		New news = null;
		String sql = "SELECT * FROM NEWMESSAGE WHERE ID = ?";
		try {
			Connection conn = DBUtil.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, new1.getId());
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				New news = new New(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				Date date = new Date(rs.getDate(5).getTime()) ,rs.getString(6),rs.getString(7));
				al.add(news,date,);
			}
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(conn);
		}
		
		return news;
	}
	public int updateNew(New new1){
		int flag = 0;
		String sql = "UPDATE NEWMESSAGE "
				+ "SET TITLE = ?,TYPE = ?,DETAILTYPE = ?,TIME = ?,ADDRESS = ?,NEWSCONTENT = ?"
				+ " WHERE ID = ?";
		try {
			Connection conn = DBUtil.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, new1.getTitle());
			ps.setString(2, new1.getType());
			ps.setString(3, new1.getDetailType());
			ps.setDate(4,new java.sql.Date(new1.getTime().getTime()));
			ps.setString(5, new1.getAddress());
			ps.setString(6, new1.getNewContent());
			ps.setInt(7, new1.getId());
			flag = ps.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(conn);
		}
		
		return flag;
		
	}
}
