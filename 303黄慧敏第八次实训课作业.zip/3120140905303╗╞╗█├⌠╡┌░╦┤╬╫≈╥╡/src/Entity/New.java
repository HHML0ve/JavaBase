package Entity;

import java.util.Date;

public class New {
	private int id;
	private String title;
	private String type;
	private String dataiType;
	private Date time;
	private String address;
	private String newContent;
	public New() {
		super();
	}
	public New(int id, String title, String type, String dataiType, Date time, String address, String newContent) {
		super();
		this.id = id;
		this.title = title;
		this.type = type;
		dataiType = dataiType;
		this.time = time;
		this.address = address;
		this.newContent = newContent;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getdataiType() {
		return dataiType;
	}
	public void setdataiType(String dataiType) {
		dataiType = dataiType;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNewContent() {
		return newContent;
	}
	public void setNewContent(String newContent) {
		this.newContent = newContent;
	}
	@Override
	public String toString() {
		return "New [id=" + id + ", title=" + title + ", type=" + type + ", dataiType=" + dataiType + ", time=" + time
				+ ", address=" + address + ", newContent=" + newContent + "]";
	}
	
}
