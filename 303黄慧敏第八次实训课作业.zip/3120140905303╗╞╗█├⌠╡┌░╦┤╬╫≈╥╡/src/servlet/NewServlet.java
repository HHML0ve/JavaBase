package servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.New;
import dao.NewMessageDao;


public class NewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public NewServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String type = request.getParameter("type");
		if("selectAllNews".equals(type)){
			selectAllNews(request,response);
		}else if("selectNewById".equals(type)){
			selectNewByid(request,response);
		}else if("updateNew".equals(type)){
			updateNew(request,response);
		}
	}
	private void updateNew(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		int id =Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("title");
		String type = request.getParameter("type1");
		String detailType = request.getParameter("detailtype");
		Date time = null;
		try {
			time = sdf.parse(request.getParameter("time"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String address = request.getParameter("address");
		String newContent = request.getParameter("newcontent");
		New n = new New(id,title,type,detailType,time,address,newContent);
		System.out.println(n);
		NewMessageDao nmd = new NewMessageDao();
		nmd.updateNew(n);
		request.getRequestDispatcher("NewServlet?type=selectAllNews").forward(request, response);
	}
	private void selectNewByid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id =Integer.parseInt(request.getParameter("id")); 
		NewMessageDao nmd = new NewMessageDao();
		New n = nmd.selectNewById(new New(id,null,null,null,null,null,null));
		request.setAttribute("new", n);
		request.getRequestDispatcher("updateNew.jsp").forward(request, response);
	
	}
	private void selectAllNews(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		NewMessageDao nmd = new NewMessageDao();
		ArrayList<New> newsList = nmd.selectAllNews();
		request.setAttribute("newsList", newsList);
		request.getRequestDispatcher("newAll.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
