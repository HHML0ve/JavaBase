package com.test;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentDao;
import com.entity.StuInfo;

import sun.awt.RepaintArea;

/**
 * Servlet implementation class StuServlet
 */
public class StuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String op = request.getParameter("type");
		if(op.equals("addStu")){
			doAdd(request, response);
		}
		if(op.equals("seleAll")){
			doSeleAll(request, response);
		}
		if(op.equals("updateStu")){
			doUpdate(request, response);
		}
	}

	
	/**
	 *����ѧ����Ϣ
	 *
	 **/
	public void doAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		StuInfo stu = new StuInfo();
		stu.setStuName(request.getParameter("userName"));
		stu.setStuSex(request.getParameter("userSex"));
		stu.setStuScore(Double.valueOf(request.getParameter("userScore")));
		stu.setStuRemark(request.getParameter("userRemark"));
		StudentDao stuDao = new StudentDao();
		if(stuDao.addStu(stu)){
			response.sendRedirect("../forword.jsp");
		}else{
			response.sendRedirect("../add.jsp");
		}
	}
	
	
	/**
	 *��ѯ����ѧ����Ϣ
	 *
	 **/
	public void doSeleAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		StudentDao stuDao = new StudentDao();
		ArrayList<StuInfo> lst = stuDao.getAllStudent();
		request.setAttribute("lst", lst);
		request.getRequestDispatcher("../show.jsp").forward(request, response);
	}
	
	/**
	 *����id���޸�ѧ����Ϣ
	 *
	 **/
	public void doUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.valueOf(request.getParameter("id"));
		StudentDao stuDao = new StudentDao();
		StuInfo stu = stuDao.changeOneStuByID(id);
		request.setAttribute("stu", stu);
		request.getRequestDispatcher("../update.jsp").forward(request, response);
	}
}
