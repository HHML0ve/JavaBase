package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.entity.StuInfo;
import com.util.DBUtil;
/**
 * @ѧ����Ϣ������
 * */
public class StudentDao {

	
	public boolean addStu(StuInfo stu){
		String sql = "insert into studentInfo values(?,?,?,?)";
		boolean flag = false;
		Connection conn = DBUtil.getConn();
		PreparedStatement smt = null;
		try {
			smt = conn.prepareStatement(sql);
			smt.setString(1, stu.getStuName());
			smt.setString(2, stu.getStuSex());
			smt.setDouble(3, stu.getStuScore());
			smt.setString(4, stu.getStuRemark());
			int i = smt.executeUpdate();
			if(i>0){
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(conn, null, smt);
		}
		return flag;
	}
	
	//��ѯ��Ϣ
	public ArrayList<StuInfo> getAllStudent(){
		String sql = "select * from studentInfo";
		ArrayList<StuInfo> lst = new ArrayList<StuInfo>();
		Connection conn = DBUtil.getConn();
		PreparedStatement smt = null;
		ResultSet rs = null;
		try {
			smt = conn.prepareStatement(sql);
			rs = smt.executeQuery();
			while(rs.next()){
				StuInfo stu = new StuInfo();
				stu.setStuID(rs.getInt(1));
				stu.setStuName(rs.getString(2));
				stu.setStuSex(rs.getString(3));
				stu.setStuScore(rs.getDouble(4));
				stu.setStuRemark(rs.getString(5));
				lst.add(stu);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(conn,smt);
			try{
			if(null != rs){
				rs.close();
			}
			}catch (Exception e) {
			}
		}
		return lst;
	}

	//��ѯҪ�޸ĵ���Ϣ	
	public StuInfo changeOneStuByID(int id){
		String sql = "select * from studentInfo where stuID = ?";
		StuInfo stu = new StuInfo();
		Connection conn = DBUtil.getConn();
		PreparedStatement smt = null;
		ResultSet rs = null;
		try {
			smt = conn.prepareStatement(sql);
			smt.setInt(1, id);
			rs = smt.executeQuery();
			while(rs.next()){
				stu.setStuID(rs.getInt(1));
				stu.setStuName(rs.getString(2));
				stu.setStuSex(rs.getString(3));
				stu.setStuScore(rs.getDouble(4));
				stu.setStuRemark(rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.close(conn, smt);
			try{
				if(null != rs){
					rs.close();
				}
				}catch (Exception e) {
				}
		}
		return stu;
	}
}
